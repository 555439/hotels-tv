'use client';

import Link from 'next/link';

export default function Hero() {
  return (
    <section 
      className="relative min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-900 via-purple-900 to-indigo-900"
      style={{
        backgroundImage: `url('https://readdy.ai/api/search-image?query=Modern%20luxury%20hotel%20lobby%20with%20elegant%20televisions%20and%20digital%20displays%2C%20contemporary%20interior%20design%20with%20ambient%20lighting%2C%20sophisticated%20hospitality%20technology%20setup%2C%20professional%20hotel%20reception%20area%20with%20multiple%20TV%20screens%20showing%20entertainment%20content%2C%20premium%20hotel%20atmosphere%20with%20modern%20amenities%20and%20digital%20entertainment%20systems&width=1920&height=1080&seq=hero-hotel-tv&orientation=landscape')`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundBlendMode: 'overlay'
      }}
    >
      <div className="absolute inset-0 bg-black/50"></div>
      
      <div className="relative z-10 w-full max-w-7xl mx-auto px-6 text-center text-white">
        <div className="mb-8">
          <h1 className="text-6xl font-bold mb-4" style={{ fontFamily: 'Pacifico, serif' }}>
            AES Hôtel TV
          </h1>
          <div className="w-24 h-1 bg-gradient-to-r from-orange-400 to-red-500 mx-auto mb-8"></div>
        </div>
        
        <h2 className="text-4xl md:text-5xl font-bold mb-6 leading-tight">
          Solution IPTV Professionnelle
          <br />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-400 to-red-500">
            pour Hôtels & Auberges
          </span>
        </h2>
        
        <p className="text-xl md:text-2xl mb-8 text-gray-200 max-w-4xl mx-auto leading-relaxed">
          Révolutionnez l'expérience télévisuelle de vos clients avec notre service IPTV haute qualité. 
          Minimisez vos coûts de télévision satellitaire en utilisant votre connexion internet existante.
        </p>
        
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12">
          <Link 
            href="#pricing" 
            className="bg-gradient-to-r from-orange-500 to-red-600 hover:from-orange-600 hover:to-red-700 text-white px-8 py-4 rounded-full font-semibold text-lg transition-all duration-300 transform hover:scale-105 shadow-lg whitespace-nowrap"
          >
            Découvrir nos forfaits
          </Link>
          <Link 
            href="#contact" 
            className="border-2 border-white text-white hover:bg-white hover:text-gray-900 px-8 py-4 rounded-full font-semibold text-lg transition-all duration-300 whitespace-nowrap"
          >
            Nous contacter
          </Link>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
          <div className="bg-white/10 backdrop-blur-md rounded-lg p-6 border border-white/20">
            <div className="w-12 h-12 bg-gradient-to-r from-orange-400 to-red-500 rounded-full flex items-center justify-center mb-4 mx-auto">
              <i className="ri-tv-line text-white text-xl"></i>
            </div>
            <h3 className="text-xl font-semibold mb-2">Économies Garanties</h3>
            <p className="text-gray-200">Réduisez vos coûts de télévision satellitaire jusqu'à 70%</p>
          </div>
          
          <div className="bg-white/10 backdrop-blur-md rounded-lg p-6 border border-white/20">
            <div className="w-12 h-12 bg-gradient-to-r from-orange-400 to-red-500 rounded-full flex items-center justify-center mb-4 mx-auto">
              <i className="ri-wifi-line text-white text-xl"></i>
            </div>
            <h3 className="text-xl font-semibold mb-2">Internet Existant</h3>
            <p className="text-gray-200">Utilisez votre connexion internet actuelle</p>
          </div>
          
          <div className="bg-white/10 backdrop-blur-md rounded-lg p-6 border border-white/20">
            <div className="w-12 h-12 bg-gradient-to-r from-orange-400 to-red-500 rounded-full flex items-center justify-center mb-4 mx-auto">
              <i className="ri-settings-line text-white text-xl"></i>
            </div>
            <h3 className="text-xl font-semibold mb-2">Installation Facile</h3>
            <p className="text-gray-200">Compatible Android et WebOS</p>
          </div>
        </div>
      </div>
    </section>
  );
}