'use client';

import { useState } from 'react';

export default function ContactForm() {
  const [formData, setFormData] = useState({
    hotelName: '',
    contactPerson: '',
    email: '',
    phone: '',
    tvType: '',
    tvBrand: '',
    roomsCount: '',
    hasHighSpeedWifi: '',
    selectedPlan: '',
    message: ''
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    try {
      const response = await fetch('https://formsubmit.co/aesipsaheltv@gmail.com', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams({
          'Nom de l\'hôtel': formData.hotelName,
          'Personne de contact': formData.contactPerson,
          'Email': formData.email,
          'Téléphone': formData.phone,
          'Type de télé': formData.tvType,
          'Marque du téléviseur': formData.tvBrand,
          'Nombre de chambres': formData.roomsCount,
          'WiFi haut débit': formData.hasHighSpeedWifi,
          'Forfait choisi': formData.selectedPlan,
          'Message': formData.message
        }).toString()
      });

      if (response.ok) {
        setSubmitStatus('success');
        setFormData({
          hotelName: '',
          contactPerson: '',
          email: '',
          phone: '',
          tvType: '',
          tvBrand: '',
          roomsCount: '',
          hasHighSpeedWifi: '',
          selectedPlan: '',
          message: ''
        });
      } else {
        setSubmitStatus('error');
      }
    } catch (error) {
      setSubmitStatus('error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  return (
    <section id="contact" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Demandez un Devis
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Remplissez ce formulaire pour recevoir une offre personnalisée pour votre établissement
          </p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <div className="bg-white rounded-xl shadow-lg p-8">
            <h3 className="text-2xl font-semibold text-gray-900 mb-6">
              Informations de Contact
            </h3>
            
            <div className="space-y-6">
              <div className="flex items-center">
                <div className="w-12 h-12 bg-gradient-to-r from-orange-500 to-red-600 rounded-full flex items-center justify-center mr-4">
                  <i className="ri-mail-line text-white"></i>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900">Email</h4>
                  <p className="text-gray-600">aesipsaheltv@gmail.com</p>
                </div>
              </div>
              
              <div className="flex items-center">
                <div className="w-12 h-12 bg-gradient-to-r from-orange-500 to-red-600 rounded-full flex items-center justify-center mr-4">
                  <i className="ri-phone-line text-white"></i>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900">Téléphone</h4>
                  <p className="text-gray-600">50-53-57-81</p>
                </div>
              </div>
              
              <div className="flex items-center">
                <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-green-600 rounded-full flex items-center justify-center mr-4">
                  <i className="ri-whatsapp-line text-white"></i>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900">WhatsApp</h4>
                  <a href="https://wa.me/22679949312" className="text-green-600 hover:text-green-700">
                    +226 79 94 93 12
                  </a>
                </div>
              </div>
            </div>
            
            <div className="mt-8 p-6 bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg">
              <h4 className="font-semibold text-gray-900 mb-3">
                Pourquoi Nous Choisir ?
              </h4>
              <ul className="space-y-2 text-gray-600">
                <li className="flex items-center">
                  <i className="ri-check-line text-green-500 mr-2"></i>
                  Installation professionnelle
                </li>
                <li className="flex items-center">
                  <i className="ri-check-line text-green-500 mr-2"></i>
                  Support technique 24/7
                </li>
                <li className="flex items-center">
                  <i className="ri-check-line text-green-500 mr-2"></i>
                  Garantie de satisfaction
                </li>
                <li className="flex items-center">
                  <i className="ri-check-line text-green-500 mr-2"></i>
                  Prix compétitifs
                </li>
              </ul>
            </div>
          </div>
          
          <div className="bg-white rounded-xl shadow-lg p-8">
            <form id="hotel-iptv-form" onSubmit={handleSubmit}>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Nom de l'hôtel *
                  </label>
                  <input
                    type="text"
                    name="hotelName"
                    value={formData.hotelName}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Personne de contact *
                  </label>
                  <input
                    type="text"
                    name="contactPerson"
                    value={formData.contactPerson}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Email *
                  </label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Téléphone *
                  </label>
                  <input
                    type="tel"
                    name="phone"
                    value={formData.phone}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Type de télé *
                  </label>
                  <div className="relative">
                    <select
                      name="tvType"
                      value={formData.tvType}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent appearance-none pr-8"
                    >
                      <option value="">Sélectionner...</option>
                      <option value="Android TV">Android TV</option>
                      <option value="WebOS">WebOS</option>
                      <option value="Autre">Autre</option>
                    </select>
                    <i className="ri-arrow-down-s-line absolute right-3 top-3 text-gray-400"></i>
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Marque du téléviseur *
                  </label>
                  <input
                    type="text"
                    name="tvBrand"
                    value={formData.tvBrand}
                    onChange={handleChange}
                    required
                    placeholder="ex: Samsung, LG, Sony..."
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Nombre de chambres *
                  </label>
                  <input
                    type="number"
                    name="roomsCount"
                    value={formData.roomsCount}
                    onChange={handleChange}
                    required
                    min="1"
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    WiFi haut débit *
                  </label>
                  <div className="relative">
                    <select
                      name="hasHighSpeedWifi"
                      value={formData.hasHighSpeedWifi}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent appearance-none pr-8"
                    >
                      <option value="">Sélectionner...</option>
                      <option value="Oui">Oui</option>
                      <option value="Non">Non</option>
                    </select>
                    <i className="ri-arrow-down-s-line absolute right-3 top-3 text-gray-400"></i>
                  </div>
                </div>
                
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Forfait choisi *
                  </label>
                  <div className="relative">
                    <select
                      name="selectedPlan"
                      value={formData.selectedPlan}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent appearance-none pr-8"
                    >
                      <option value="">Sélectionner un forfait...</option>
                      <option value="1 An - 30,000 FCFA">1 An - 30,000 FCFA</option>
                      <option value="2 Ans - 55,000 FCFA">2 Ans - 55,000 FCFA</option>
                      <option value="Lifetime - 100,000 FCFA">Lifetime - 100,000 FCFA</option>
                      <option value="Lifetime sans box - 70,000 FCFA">Lifetime sans box - 70,000 FCFA</option>
                      <option value="Box Android seule - 35,000 FCFA">Box Android seule - 35,000 FCFA</option>
                    </select>
                    <i className="ri-arrow-down-s-line absolute right-3 top-3 text-gray-400"></i>
                  </div>
                </div>
                
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Message complémentaire
                  </label>
                  <textarea
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    rows={4}
                    maxLength={500}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent resize-none"
                    placeholder="Décrivez vos besoins spécifiques..."
                  ></textarea>
                  <div className="text-right text-sm text-gray-500 mt-1">
                    {formData.message.length}/500
                  </div>
                </div>
              </div>
              
              <div className="mt-8">
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full bg-gradient-to-r from-orange-500 to-red-600 hover:from-orange-600 hover:to-red-700 text-white font-semibold py-4 px-6 rounded-lg transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed whitespace-nowrap"
                >
                  {isSubmitting ? 'Envoi en cours...' : 'Envoyer la demande'}
                </button>
              </div>
              
              {submitStatus === 'success' && (
                <div className="mt-4 p-4 bg-green-50 border border-green-200 rounded-lg">
                  <p className="text-green-800">
                    Votre demande a été envoyée avec succès ! Nous vous contactons dans les plus brefs délais.
                  </p>
                </div>
              )}
              
              {submitStatus === 'error' && (
                <div className="mt-4 p-4 bg-red-50 border border-red-200 rounded-lg">
                  <p className="text-red-800">
                    Une erreur s'est produite lors de l'envoi. Veuillez réessayer ou nous contacter directement.
                  </p>
                </div>
              )}
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}