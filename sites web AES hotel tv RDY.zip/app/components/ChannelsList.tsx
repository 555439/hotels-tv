'use client';

export default function ChannelsList() {
  const channels = [
    { name: 'Canal+', category: 'Cinéma', country: 'France' },
    { name: 'BeIN Sports', category: 'Sport', country: 'International' },
    { name: 'France 24', category: 'Actualités', country: 'France' },
    { name: 'TV5 Monde', category: 'Généraliste', country: 'France' },
    { name: 'Eurosport', category: 'Sport', country: 'Europe' },
    { name: 'National Geographic', category: 'Documentaire', country: 'USA' },
    { name: 'Discovery Channel', category: 'Documentaire', country: 'USA' },
    { name: 'MTV', category: 'Musique', country: 'USA' },
    { name: 'CNN International', category: 'Actualités', country: 'USA' },
    { name: 'BBC World', category: 'Actualités', country: 'UK' },
    { name: 'RTI 1', category: 'Généraliste', country: 'Côte d\'Ivoire' },
    { name: 'RTI 2', category: 'Généraliste', country: 'Côte d\'Ivoire' },
    { name: 'A+', category: 'Divertissement', country: 'Afrique' },
    { name: 'Cartoon Network', category: 'Enfants', country: 'USA' },
    { name: 'Disney Channel', category: 'Enfants', country: 'USA' },
    { name: 'TF1', category: 'Généraliste', country: 'France' },
    { name: 'France 2', category: 'Généraliste', country: 'France' },
    { name: 'M6', category: 'Généraliste', country: 'France' },
    { name: 'RFI', category: 'Actualités', country: 'France' },
    { name: 'TV5 Afrique', category: 'Généraliste', country: 'Afrique' },
    { name: 'Africa24', category: 'Actualités', country: 'Afrique' },
    { name: 'Fashion TV', category: 'Lifestyle', country: 'France' },
    { name: 'Trace TV', category: 'Musique', country: 'France' },
    { name: 'NCI', category: 'Généraliste', country: 'Côte d\'Ivoire' },
    { name: 'Life TV', category: 'Généraliste', country: 'Côte d\'Ivoire' },
    { name: 'Télé Sport', category: 'Sport', country: 'Côte d\'Ivoire' },
    { name: 'Al Jazeera', category: 'Actualités', country: 'Qatar' },
    { name: 'ESPN', category: 'Sport', country: 'USA' },
    { name: 'Fox News', category: 'Actualités', country: 'USA' },
    { name: 'Sky News', category: 'Actualités', country: 'UK' }
  ];

  const categories = [...new Set(channels.map(channel => channel.category))];

  return (
    <section id="channels" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Chaînes Disponibles
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Plus de 500 chaînes internationales et locales pour satisfaire tous vos clients
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {categories.map((category, index) => (
            <div key={index} className="bg-gray-50 rounded-xl p-6">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 bg-gradient-to-r from-orange-500 to-red-600 rounded-full flex items-center justify-center mr-4">
                  <i className={`ri-${category === 'Sport' ? 'football' : category === 'Actualités' ? 'news' : category === 'Cinéma' ? 'movie' : category === 'Enfants' ? 'bear-smile' : category === 'Musique' ? 'music' : 'tv'}-line text-white`}></i>
                </div>
                <h3 className="text-xl font-semibold text-gray-900">{category}</h3>
              </div>
              <div className="space-y-2">
                {channels
                  .filter(channel => channel.category === category)
                  .slice(0, 5)
                  .map((channel, channelIndex) => (
                    <div key={channelIndex} className="flex items-center justify-between">
                      <span className="text-gray-700">{channel.name}</span>
                      <span className="text-sm text-gray-500">{channel.country}</span>
                    </div>
                  ))}
                {channels.filter(channel => channel.category === category).length > 5 && (
                  <div className="text-center pt-2">
                    <span className="text-sm text-orange-600 font-medium">
                      +{channels.filter(channel => channel.category === category).length - 5} autres chaînes
                    </span>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
        
        <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl p-8 text-white text-center">
          <h3 className="text-3xl font-bold mb-4">
            Plus de 500 Chaînes Disponibles
          </h3>
          <p className="text-xl mb-6 text-white/90">
            Divertissement, actualités, sport, documentaires et plus encore
          </p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-2xl mx-auto">
            <div className="text-center">
              <div className="text-3xl font-bold">150+</div>
              <div className="text-sm text-white/80">Chaînes Françaises</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold">100+</div>
              <div className="text-sm text-white/80">Chaînes Africaines</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold">200+</div>
              <div className="text-sm text-white/80">Chaînes Internationales</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold">50+</div>
              <div className="text-sm text-white/80">Chaînes Sport</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}