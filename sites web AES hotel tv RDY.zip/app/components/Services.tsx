'use client';

export default function Services() {
  return (
    <section id="services" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Nos Services IPTV
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Une solution complète pour moderniser l'expérience télévisuelle de votre établissement
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <div className="bg-white rounded-xl shadow-lg p-8 hover:shadow-xl transition-shadow duration-300">
            <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center mb-6">
              <i className="ri-hotel-line text-white text-2xl"></i>
            </div>
            <h3 className="text-2xl font-semibold mb-4 text-gray-900">
              Hôtels & Auberges
            </h3>
            <p className="text-gray-600 mb-6">
              Solution spécialement conçue pour les établissements hôteliers de toutes tailles
            </p>
            <ul className="space-y-2 text-gray-600">
              <li className="flex items-center">
                <i className="ri-check-line text-green-500 mr-2"></i>
                Installation sur mesure
              </li>
              <li className="flex items-center">
                <i className="ri-check-line text-green-500 mr-2"></i>
                Support technique 24/7
              </li>
              <li className="flex items-center">
                <i className="ri-check-line text-green-500 mr-2"></i>
                Maintenance incluse
              </li>
            </ul>
          </div>
          
          <div className="bg-white rounded-xl shadow-lg p-8 hover:shadow-xl transition-shadow duration-300">
            <div className="w-16 h-16 bg-gradient-to-r from-orange-500 to-red-600 rounded-full flex items-center justify-center mb-6">
              <i className="ri-smartphone-line text-white text-2xl"></i>
            </div>
            <h3 className="text-2xl font-semibold mb-4 text-gray-900">
              Compatible Multi-Plateformes
            </h3>
            <p className="text-gray-600 mb-6">
              Fonctionne avec tous les types de téléviseurs modernes
            </p>
            <ul className="space-y-2 text-gray-600">
              <li className="flex items-center">
                <i className="ri-check-line text-green-500 mr-2"></i>
                Android TV
              </li>
              <li className="flex items-center">
                <i className="ri-check-line text-green-500 mr-2"></i>
                WebOS (LG)
              </li>
              <li className="flex items-center">
                <i className="ri-check-line text-green-500 mr-2"></i>
                Box Android certifiée
              </li>
            </ul>
          </div>
          
          <div className="bg-white rounded-xl shadow-lg p-8 hover:shadow-xl transition-shadow duration-300">
            <div className="w-16 h-16 bg-gradient-to-r from-green-500 to-teal-600 rounded-full flex items-center justify-center mb-6">
              <i className="ri-money-dollar-circle-line text-white text-2xl"></i>
            </div>
            <h3 className="text-2xl font-semibold mb-4 text-gray-900">
              Économies Importantes
            </h3>
            <p className="text-gray-600 mb-6">
              Réduisez drastiquement vos coûts de télévision satellitaire
            </p>
            <ul className="space-y-2 text-gray-600">
              <li className="flex items-center">
                <i className="ri-check-line text-green-500 mr-2"></i>
                Pas d'antenne satellite
              </li>
              <li className="flex items-center">
                <i className="ri-check-line text-green-500 mr-2"></i>
                Internet existant
              </li>
              <li className="flex items-center">
                <i className="ri-check-line text-green-500 mr-2"></i>
                ROI rapide
              </li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}