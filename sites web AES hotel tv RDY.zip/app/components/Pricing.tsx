'use client';

export default function Pricing() {
  const plans = [
    {
      name: '1 An',
      price: '30,000',
      duration: 'FCFA',
      period: 'pour 1 an',
      popular: false,
      features: [
        'Accès complet aux chaînes',
        'Support technique',
        'Mises à jour incluses',
        'Installation basique',
        'Garantie 1 an'
      ]
    },
    {
      name: '2 Ans',
      price: '55,000',
      duration: 'FCFA',
      period: 'pour 2 ans',
      popular: true,
      features: [
        'Accès complet aux chaînes',
        'Support technique prioritaire',
        'Mises à jour incluses',
        'Installation professionnelle',
        'Garantie 2 ans',
        'Économie de 5,000 FCFA'
      ]
    },
    {
      name: 'Lifetime',
      price: '100,000',
      duration: 'FCFA',
      period: 'à vie',
      popular: false,
      features: [
        'Accès illimité à vie',
        'Box Android certifiée incluse',
        'Support technique VIP',
        'Installation premium',
        'Garantie à vie',
        'Mises à jour gratuites'
      ]
    },
    {
      name: 'Lifetime (sans box)',
      price: '70,000',
      duration: 'FCFA',
      period: 'à vie',
      popular: false,
      features: [
        'Accès illimité à vie',
        'Support technique VIP',
        'Installation premium',
        'Garantie à vie',
        'Mises à jour gratuites',
        'Box non incluse'
      ]
    }
  ];

  return (
    <section id="pricing" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Nos Forfaits
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Choisissez le forfait qui convient le mieux à votre établissement
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          {plans.map((plan, index) => (
            <div key={index} className={`bg-white rounded-xl shadow-lg p-8 relative ${plan.popular ? 'ring-2 ring-orange-500 transform scale-105' : ''}`}>
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <span className="bg-gradient-to-r from-orange-500 to-red-600 text-white px-4 py-2 rounded-full text-sm font-semibold">
                    Plus Populaire
                  </span>
                </div>
              )}
              
              <div className="text-center mb-6">
                <h3 className="text-2xl font-semibold text-gray-900 mb-2">
                  {plan.name}
                </h3>
                <div className="text-4xl font-bold text-gray-900 mb-2">
                  {plan.price}
                  <span className="text-lg font-normal text-gray-600 ml-1">
                    {plan.duration}
                  </span>
                </div>
                <p className="text-gray-600">{plan.period}</p>
              </div>
              
              <ul className="space-y-3 mb-8">
                {plan.features.map((feature, featureIndex) => (
                  <li key={featureIndex} className="flex items-center">
                    <i className="ri-check-line text-green-500 mr-3"></i>
                    <span className="text-gray-600">{feature}</span>
                  </li>
                ))}
              </ul>
              
              <button className={`w-full py-3 rounded-lg font-semibold transition-all duration-300 whitespace-nowrap ${
                plan.popular 
                  ? 'bg-gradient-to-r from-orange-500 to-red-600 text-white hover:from-orange-600 hover:to-red-700' 
                  : 'bg-gray-100 text-gray-900 hover:bg-gray-200'
              }`}>
                Choisir ce forfait
              </button>
            </div>
          ))}
        </div>
        
        <div className="bg-white rounded-xl shadow-lg p-8">
          <div className="text-center mb-8">
            <h3 className="text-3xl font-bold text-gray-900 mb-4">
              Box Android Certifiée
            </h3>
            <p className="text-xl text-gray-600">
              Disponible séparément pour une expérience optimale
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            <div>
              <div className="bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg p-6 text-white">
                <div className="text-center">
                  <div className="text-4xl font-bold mb-2">35,000 FCFA</div>
                  <p className="text-blue-100">Box Android certifiée avec garantie</p>
                </div>
              </div>
            </div>
            
            <div>
              <ul className="space-y-3">
                <li className="flex items-center">
                  <i className="ri-check-line text-green-500 mr-3"></i>
                  <span>Android TV certifié</span>
                </li>
                <li className="flex items-center">
                  <i className="ri-check-line text-green-500 mr-3"></i>
                  <span>Garantie constructeur</span>
                </li>
                <li className="flex items-center">
                  <i className="ri-check-line text-green-500 mr-3"></i>
                  <span>Installation incluse</span>
                </li>
                <li className="flex items-center">
                  <i className="ri-check-line text-green-500 mr-3"></i>
                  <span>Support technique</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}