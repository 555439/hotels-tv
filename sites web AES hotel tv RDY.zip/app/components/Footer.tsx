'use client';

import Link from 'next/link';

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white py-16">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div>
            <h3 className="text-2xl font-bold mb-4" style={{ fontFamily: 'Pacifico, serif' }}>
              AES Hôtel TV
            </h3>
            <p className="text-gray-300 mb-6">
              Votre partenaire de confiance pour les solutions IPTV professionnelles destinées aux hôtels et établissements d'hébergement.
            </p>
            <div className="flex space-x-4">
              <a href="https://wa.me/22679949312" className="w-10 h-10 bg-green-600 rounded-full flex items-center justify-center hover:bg-green-700 transition-colors">
                <i className="ri-whatsapp-line"></i>
              </a>
              <a href="mailto:aesipsaheltv@gmail.com" className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center hover:bg-blue-700 transition-colors">
                <i className="ri-mail-line"></i>
              </a>
              <a href="tel:50535781" className="w-10 h-10 bg-orange-600 rounded-full flex items-center justify-center hover:bg-orange-700 transition-colors">
                <i className="ri-phone-line"></i>
              </a>
            </div>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold mb-4">Services</h4>
            <ul className="space-y-2 text-gray-300">
              <li><Link href="#services" className="hover:text-white transition-colors">Installation IPTV</Link></li>
              <li><Link href="#pricing" className="hover:text-white transition-colors">Forfaits</Link></li>
              <li><Link href="#features" className="hover:text-white transition-colors">Applications</Link></li>
              <li><Link href="#contact" className="hover:text-white transition-colors">Support technique</Link></li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold mb-4">Forfaits</h4>
            <ul className="space-y-2 text-gray-300">
              <li>1 An - 30,000 FCFA</li>
              <li>2 Ans - 55,000 FCFA</li>
              <li>Lifetime - 100,000 FCFA</li>
              <li>Box Android - 35,000 FCFA</li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold mb-4">Contact</h4>
            <div className="space-y-3 text-gray-300">
              <div className="flex items-center">
                <i className="ri-mail-line mr-2"></i>
                <span>aesipsaheltv@gmail.com</span>
              </div>
              <div className="flex items-center">
                <i className="ri-phone-line mr-2"></i>
                <span>50-53-57-81</span>
              </div>
              <div className="flex items-center">
                <i className="ri-whatsapp-line mr-2"></i>
                <span>+226 79 94 93 12</span>
              </div>
            </div>
          </div>
        </div>
        
        <div className="border-t border-gray-800 mt-12 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm mb-4 md:mb-0">
              © 2024 AES Hôtel TV. Tous droits réservés.
            </p>
            <div className="flex space-x-6 text-sm text-gray-400">
              <Link href="#" className="hover:text-white transition-colors">Conditions d'utilisation</Link>
              <Link href="#" className="hover:text-white transition-colors">Politique de confidentialité</Link>
              <Link href="#contact" className="hover:text-white transition-colors">Support</Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}