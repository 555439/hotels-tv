'use client';

export default function Features() {
  const apps = [
    {
      name: 'IBO Player Pro',
      image: 'https://readdy.ai/api/search-image?query=IBO%20Player%20Pro%20application%20logo%20icon%2C%20modern%20IPTV%20streaming%20app%20interface%2C%20professional%20television%20streaming%20software%20logo%2C%20clean%20digital%20media%20player%20branding%2C%20contemporary%20entertainment%20application%20design&width=200&height=200&seq=ibo-player&orientation=squarish',
      description: 'Application IPTV professionnelle avec interface moderne'
    },
    {
      name: 'Nanomid',
      image: 'https://readdy.ai/api/search-image?query=Nanomid%20IPTV%20application%20logo%2C%20streaming%20media%20player%20interface%2C%20professional%20television%20app%20icon%2C%20modern%20entertainment%20software%20branding%2C%20digital%20TV%20streaming%20application%20design&width=200&height=200&seq=nanomid&orientation=squarish',
      description: 'Solution de streaming avancée pour hôtels'
    },
    {
      name: 'Bay IPTV',
      image: 'https://readdy.ai/api/search-image?query=Bay%20IPTV%20application%20logo%20icon%2C%20professional%20streaming%20media%20player%2C%20modern%20television%20entertainment%20app%20branding%2C%20digital%20IPTV%20service%20interface%20design%2C%20contemporary%20media%20streaming%20software&width=200&height=200&seq=bay-iptv&orientation=squarish',
      description: 'Plateforme IPTV fiable et performante'
    },
    {
      name: 'ETV Pro',
      image: 'https://readdy.ai/api/search-image?query=ETV%20Pro%20application%20logo%2C%20professional%20IPTV%20streaming%20software%20icon%2C%20modern%20television%20entertainment%20app%20branding%2C%20digital%20media%20player%20interface%20design%2C%20contemporary%20streaming%20service%20logo&width=200&height=200&seq=etv-pro&orientation=squarish',
      description: 'Solution IPTV complète pour professionnels'
    },
    {
      name: 'Smarters IPTV Pro',
      image: 'https://readdy.ai/api/search-image?query=Smarters%20IPTV%20Pro%20application%20logo%2C%20professional%20streaming%20media%20player%20icon%2C%20modern%20television%20entertainment%20app%20branding%2C%20digital%20IPTV%20service%20interface%2C%20contemporary%20media%20streaming%20software%20design&width=200&height=200&seq=smarters-iptv&orientation=squarish',
      description: 'Application IPTV premium avec fonctionnalités avancées'
    }
  ];

  return (
    <section id="features" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Applications Compatibles
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Nos services fonctionnent avec les meilleures applications IPTV du marché
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {apps.map((app, index) => (
            <div key={index} className="bg-gray-50 rounded-xl p-6 hover:shadow-lg transition-shadow duration-300">
              <div className="w-24 h-24 mx-auto mb-4 rounded-lg overflow-hidden">
                <img 
                  src={app.image} 
                  alt={app.name}
                  className="w-full h-full object-cover"
                />
              </div>
              <h3 className="text-xl font-semibold text-center mb-2 text-gray-900">
                {app.name}
              </h3>
              <p className="text-gray-600 text-center">
                {app.description}
              </p>
            </div>
          ))}
        </div>
        
        <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl p-8 text-white">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            <div>
              <h3 className="text-3xl font-bold mb-4">
                Pourquoi Choisir Notre Solution ?
              </h3>
              <ul className="space-y-3">
                <li className="flex items-center">
                  <i className="ri-check-line text-green-300 mr-3 text-xl"></i>
                  <span>Installation professionnelle incluse</span>
                </li>
                <li className="flex items-center">
                  <i className="ri-check-line text-green-300 mr-3 text-xl"></i>
                  <span>Support technique 24/7</span>
                </li>
                <li className="flex items-center">
                  <i className="ri-check-line text-green-300 mr-3 text-xl"></i>
                  <span>Mises à jour automatiques</span>
                </li>
                <li className="flex items-center">
                  <i className="ri-check-line text-green-300 mr-3 text-xl"></i>
                  <span>Garantie de satisfaction</span>
                </li>
              </ul>
            </div>
            <div className="text-center">
              <div className="w-32 h-32 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-award-line text-6xl text-white"></i>
              </div>
              <h4 className="text-2xl font-semibold mb-2">
                Qualité Professionnelle
              </h4>
              <p className="text-white/90">
                Solutions éprouvées par des centaines d'établissements
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}