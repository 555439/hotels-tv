'use client';

import Hero from './components/Hero';
import Services from './components/Services';
import Pricing from './components/Pricing';
import Features from './components/Features';
import ChannelsList from './components/ChannelsList';
import ContactForm from './components/ContactForm';
import Footer from './components/Footer';
import WhatsAppFloat from './components/WhatsAppFloat';

export default function Home() {
  return (
    <main className="min-h-screen">
      <Hero />
      <Services />
      <Features />
      <Pricing />
      <ChannelsList />
      <ContactForm />
      <Footer />
      <WhatsAppFloat />
    </main>
  );
}